package com.example.startselect

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.*
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.app.NotificationCompat

class OverlayService : Service() {

    companion object {
        private const val TAG = "OverlayService"
        private const val CHANNEL_ID = "overlay_channel"

        private const val START_NAME = "KEYCODE_BUTTON_START"
        private const val SELECT_NAME = "KEYCODE_BUTTON_SELECT"

        private const val ALT_START = "KEYCODE_MENU"
        private const val ALT_SELECT = "KEYCODE_TAB"
    }

    private lateinit var wm: WindowManager
    private var leftView: View? = null
    private var rightView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotif()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addButtons()
        Toast.makeText(this, "Overlay ON", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { leftView?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { rightView?.let { wm.removeView(it) } } catch (_: Exception) {}
        Toast.makeText(this, "Overlay OFF", Toast.LENGTH_SHORT).show()
    }

    private fun startForegroundNotif() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Overlay", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Start/Select overlay active")
            .setOngoing(true)
            .build()
        startForeground(1, notif)
    }

    private fun paramsAt(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x; this.y = y
    }

    private fun addButtons() {
        val w = resources.displayMetrics.widthPixels
        val leftParams = paramsAt(24, 300)
        val rightParams = paramsAt(w - 200, 300)

        val inflater = LayoutInflater.from(this)
        leftView = inflater.inflate(R.layout.overlay_button, null).apply {
            findViewById<ImageButton>(R.id.overlayBtn).apply {
                alpha = 0.7f
                setOnClickListener { sendKeyWithRoot(true) }
            }
        }
        rightView = inflater.inflate(R.layout.overlay_button, null).apply {
            findViewById<ImageButton>(R.id.overlayBtn).apply {
                alpha = 0.7f
                setOnClickListener { sendKeyWithRoot(false) }
            }
        }

        wm.addView(leftView, leftParams)
        wm.addView(rightView, rightParams)

        enableDrag(leftView!!, leftParams)
        enableDrag(rightView!!, rightParams)
    }

    private fun enableDrag(v: View, lp: WindowManager.LayoutParams) {
        var lastX = 0f
        var lastY = 0f
        v.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { lastX = ev.rawX; lastY = ev.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - lastX).toInt()
                    val dy = (ev.rawY - lastY).toInt()
                    lp.x += dx; lp.y += dy
                    wm.updateViewLayout(v, lp)
                    lastX = ev.rawX; lastY = ev.rawY
                    true
                }
                else -> false
            }
        }
    }

    private fun sendKeyWithRoot(isStart: Boolean) {
        val primary = if (isStart) START_NAME else SELECT_NAME
        val fallback = if (isStart) ALT_START else ALT_SELECT
        val ok = runSuKey(primary)
        if (!ok) runSuKey(fallback)
    }

    private fun runSuKey(nameOrCode: String): Boolean {
        val cmd = "input keyevent $nameOrCode"
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val rc = p.waitFor()
            if (rc != 0) android.util.Log.w("OverlayService", "su rc=$rc for $nameOrCode")
            rc == 0
        } catch (t: Throwable) {
            android.util.Log.e("OverlayService", "su error", t); false
        }
    }
}
