package com.example.startselect

import android.content.Context
import android.graphics.Color
import android.view.Gravity

object Prefs {
    private const val FILE = "prefs"

    private const val KEY_SIZE_DP = "size_dp"
    private const val KEY_ALPHA = "alpha"
    private const val KEY_SHAPE = "shape"
    private const val KEY_P1_X = "p1_x"
    private const val KEY_P1_Y = "p1_y"
    private const val KEY_P2_X = "p2_x"
    private const val KEY_P2_Y = "p2_y"
    private const val KEY_SNAP = "snap"
    private const val KEY_COLOR = "color"

    fun sizeDp(ctx: Context): Int = ctx.getSharedPreferences(FILE, 0).getInt(KEY_SIZE_DP, 56)
    fun setSizeDp(ctx: Context, v: Int) { ctx.getSharedPreferences(FILE, 0).edit().putInt(KEY_SIZE_DP, v).apply() }

    fun alpha(ctx: Context): Float = ctx.getSharedPreferences(FILE, 0).getFloat(KEY_ALPHA, 0.7f)
    fun setAlpha(ctx: Context, v: Float) { ctx.getSharedPreferences(FILE, 0).edit().putFloat(KEY_ALPHA, v).apply() }

    fun shape(ctx: Context): Int = ctx.getSharedPreferences(FILE, 0).getInt(KEY_SHAPE, 0)
    fun setShape(ctx: Context, v: Int) { ctx.getSharedPreferences(FILE, 0).edit().putInt(KEY_SHAPE, v).apply() }

    fun snap(ctx: Context): Int = ctx.getSharedPreferences(FILE, 0).getInt(KEY_SNAP, Gravity.TOP)
    fun setSnap(ctx: Context, v: Int) { ctx.getSharedPreferences(FILE, 0).edit().putInt(KEY_SNAP, v).apply() }

    fun color(ctx: Context): Int = ctx.getSharedPreferences(FILE, 0).getInt(KEY_COLOR, Color.parseColor("#E53935"))
    fun setColor(ctx: Context, v: Int) { ctx.getSharedPreferences(FILE, 0).edit().putInt(KEY_COLOR, v).apply() }

    fun getP1(ctx: Context): Pair<Int,Int> {
        val sp = ctx.getSharedPreferences(FILE, 0)
        return sp.getInt(KEY_P1_X, 16) to sp.getInt(KEY_P1_Y, 16)
    }
    fun setP1(ctx: Context, x: Int, y: Int) {
        ctx.getSharedPreferences(FILE, 0).edit().putInt(KEY_P1_X, x).putInt(KEY_P1_Y, y).apply()
    }

    fun getP2(ctx: Context): Pair<Int,Int> {
        val sp = ctx.getSharedPreferences(FILE, 0)
        return sp.getInt(KEY_P2_X, 16) to sp.getInt(KEY_P2_Y, 16)
    }
    fun setP2(ctx: Context, x: Int, y: Int) {
        ctx.getSharedPreferences(FILE, 0).edit().putInt(KEY_P2_X, x).putInt(KEY_P2_Y, y).apply()
    }
}
