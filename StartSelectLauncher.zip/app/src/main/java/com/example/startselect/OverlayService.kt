package com.example.startselect

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import kotlin.math.roundToInt

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var startView: View? = null
    private var selectView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()

        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val sizeDp = Prefs.sizeDp(this)
        val alpha = Prefs.alpha(this)
        val shape = Prefs.shape(this)
        val color = Prefs.color(this)

        val pStart = makeParams(Gravity.END or Prefs.snap(this), Prefs.getP1(this))
        startView = LayoutInflater.from(this).inflate(R.layout.overlay_button, null)
        val startBtn: ImageView = startView!!.findViewById(R.id.overlayBtn)
        styleButton(startBtn, sizeDp, alpha, shape, color)
        startBtn.setOnClickListener { KeySender.sendKeycode(108) } // START
        startBtn.setOnLongClickListener { KeySender.sendLongPress(108); true }
        setDraggable(startView!!, pStart, isStart = true)

        wm.addView(startView, pStart)

        val pSelect = makeParams(Gravity.START or Prefs.snap(this), Prefs.getP2(this))
        selectView = LayoutInflater.from(this).inflate(R.layout.overlay_button, null)
        val selectBtn: ImageView = selectView!!.findViewById(R.id.overlayBtn)
        styleButton(selectBtn, sizeDp, alpha, shape, color)
        selectBtn.setImageResource(android.R.drawable.ic_media_previous)
        selectBtn.setOnClickListener { KeySender.sendKeycode(109) } // SELECT
        selectBtn.setOnLongClickListener { KeySender.sendLongPress(109); true }
        setDraggable(selectView!!, pSelect, isStart = false)

        wm.addView(selectView, pSelect)
    }

    override fun onDestroy() {
        super.onDestroy()
        startView?.let { runCatching { wm.removeView(it) } }
        selectView?.let { runCatching { wm.removeView(it) } }
    }

    private fun styleButton(btn: ImageView, sizeDp: Int, alpha: Float, shape: Int, color: Int) {
        val sz = dp(sizeDp)
        btn.layoutParams = ViewGroup.LayoutParams(sz, sz)
        btn.alpha = alpha
        if (shape == 0) btn.setBackgroundResource(R.drawable.bg_circle) else btn.setBackgroundResource(R.drawable.bg_round_rect)
        btn.background.setColorFilter(color, PorterDuff.Mode.SRC_ATOP)
    }

    private fun makeParams(gravity: Int, pos: Pair<Int,Int>): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            this.x = pos.first
            this.y = pos.second
        }
    }

    private fun setDraggable(view: View, params: WindowManager.LayoutParams, isStart: Boolean) {
        view.setOnTouchListener(object : View.OnTouchListener {
            var lastX = 0f; var lastY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - lastX).toInt()
                        val dy = (e.rawY - lastY).toInt()
                        val isRight = (params.gravity and Gravity.END) == Gravity.END
                        params.x += if (isRight) -dx else dx
                        params.y += dy
                        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(view, params)
                        lastX = e.rawX; lastY = e.rawY
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isStart) Prefs.setP1(this@OverlayService, params.x, params.y)
                        else Prefs.setP2(this@OverlayService, params.x, params.y)
                    }
                }
                return false
            }
        })
    }

    private fun dp(v: Int): Int = (resources.displayMetrics.density * v).roundToInt()

    private fun startForegroundWithNotification() {
        val id = "overlay_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(id, "Overlay", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        val txt = if (KeySender.hasRoot()) "Overlay активен (root)" else "Overlay активен (root нет)"
        val n: Notification = NotificationCompat.Builder(this, id)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Start/Select")
            .setContentText(txt)
            .build()
        startForeground(1, n)
    }
}
