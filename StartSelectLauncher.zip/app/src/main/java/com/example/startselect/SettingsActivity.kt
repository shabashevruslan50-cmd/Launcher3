package com.example.startselect

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.example.startselect.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var ui: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(ui.root)

        ui.seekSize.max = 120
        ui.seekSize.progress = Prefs.sizeDp(this)
        ui.txtSize.text = "Размер: ${Prefs.sizeDp(this)}dp"
        ui.seekSize.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val p = progress.coerceAtLeast(32)
                ui.txtSize.text = "Размер: ${p}dp"
                Prefs.setSizeDp(this@SettingsActivity, p)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        ui.seekAlpha.max = 100
        ui.seekAlpha.progress = (Prefs.alpha(this) * 100).toInt()
        ui.txtAlpha.text = "Прозрачность: ${ui.seekAlpha.progress}%"
        ui.seekAlpha.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val a = (progress.coerceIn(20, 100)) / 100f
                ui.txtAlpha.text = "Прозрачность: ${progress}%"
                Prefs.setAlpha(this@SettingsActivity, a)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        ui.switchShape.isChecked = Prefs.shape(this) == 1
        ui.switchShape.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setShape(this, if (isChecked) 1 else 0)
        }

        val snapTop = Prefs.snap(this) == Gravity.TOP
        ui.switchSnap.isChecked = !snapTop
        ui.lblSnap.text = if (snapTop) "Верх" else "Низ"
        ui.switchSnap.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setSnap(this, if (isChecked) Gravity.BOTTOM else Gravity.TOP)
            ui.lblSnap.text = if (isChecked) "Низ" else "Верх"
        }

        ui.btnRed.setOnClickListener { Prefs.setColor(this, Color.parseColor("#E53935")) }
        ui.btnWhite.setOnClickListener { Prefs.setColor(this, Color.WHITE) }
        ui.btnBlue.setOnClickListener { Prefs.setColor(this, Color.parseColor("#2196F3")) }
    }
}
