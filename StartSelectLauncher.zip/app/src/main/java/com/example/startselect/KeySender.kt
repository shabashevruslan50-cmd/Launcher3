package com.example.startselect

object KeySender {
    fun hasRoot(): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "echo rooted"))
            p.waitFor() == 0
        } catch (_: Exception) { false }
    }
    fun sendKeycode(keyCode: Int): Boolean = runSu("input keyevent $keyCode")
    fun sendLongPress(keyCode: Int): Boolean {
        val ok = runSu("input keyevent --longpress $keyCode")
        return ok || (runSu("input keyevent $keyCode") && runSu("input keyevent $keyCode"))
    }
    private fun runSu(cmd: String): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            p.waitFor() == 0
        } catch (_: Exception) { false }
    }
}
